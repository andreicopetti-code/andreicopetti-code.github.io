import type { ImageSourcePropType } from 'react-native';

/** ART_ASSETS_V4 — vegetais + frases e expressões (mescladas) + rodízio (mix) + ícone novo de utensílios */
export const ORBE_WIZARD = require('../../../assets/cocina/orbe-wizard.png') as ImageSourcePropType;

export const CAT_IMAGE: Record<string, ImageSourcePropType> = {
  alimentos: require('../../../assets/cocina/cat-alimentos.png'),
  carnes: require('../../../assets/cocina/cat-carnes.png'),
  frutas: require('../../../assets/cocina/cat-frutas.png'),
  vegetais: require('../../../assets/cocina/cat-vegetais.png'),
  padaria: require('../../../assets/cocina/cat-padaria.png'),
  'fast-food': require('../../../assets/cocina/cat-fast-food.png'),
  bebidas: require('../../../assets/cocina/cat-bebidas.png'),
  'utensílios': require('../../../assets/cocina/cat-utensilios.png'),
  mercado: require('../../../assets/cocina/cat-mercado.png'),
  'falsas amigas': require('../../../assets/cocina/cat-falsas-amigas.png'),
  'frases e expressões': require('../../../assets/cocina/cat-frases-uteis.png'),
  'rodízio': require('../../../assets/cocina/cat-rodizio.png'),
};
