import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

export default function App() {
  return (
    <View style={styles.root}>
      <Text style={styles.brand}>ORBE</Text>
      <Text style={styles.ok}>Conexao OK</Text>
      <Text style={styles.hint}>
        Se voce esta lendo isto, o Expo Go e a rede estao funcionando.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#fef6e8',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  brand: { fontSize: 42, fontWeight: '800', letterSpacing: 6, color: '#c96a20' },
  ok: { marginTop: 8, fontSize: 20, fontWeight: '700', color: '#2d1400' },
  hint: { marginTop: 10, fontSize: 13, color: '#9a7050', textAlign: 'center' },
});
